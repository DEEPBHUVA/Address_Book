﻿using Addresh_Book5th.Areas.LOC_Country.Models;
using Addresh_Book5th.Areas.LOC_State.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace Addresh_Book5th.Areas.LOC_State.Controllers
{
    [Area("LOC_State")]
    [Route("LOC_State/{Controller}/{action}")]
    public class LOC_StateController : Controller
    {
        public IConfiguration Configuration;
        public LOC_StateController(IConfiguration _configuration)
        {
            Configuration = _configuration;
        }

        public IActionResult Add(int? StateID)
        {
            #region Dropdown
            string myConnectingString1 = Configuration.GetConnectionString("MyConnectingString");
            SqlConnection conn1 = new SqlConnection(myConnectingString1);
            DataTable dt1 = new DataTable();
            conn1.Open();
            SqlCommand sqlCommand1 = conn1.CreateCommand();
            sqlCommand1.CommandType = CommandType.StoredProcedure;
            sqlCommand1.CommandText = "PR_LOC_Country_Dropdown";
            SqlDataReader objred1 = sqlCommand1.ExecuteReader();
            dt1.Load(objred1);

            List<LOC_Country_DropdownModel> list = new List<LOC_Country_DropdownModel> ();
            foreach(DataRow dr in dt1.Rows)
            {
                LOC_Country_DropdownModel dlist = new LOC_Country_DropdownModel ();
                dlist.CountryID = Convert.ToInt32(dr["CountryID"]);
                dlist.CountryName = dr["CountryName"].ToString();
                list.Add(dlist);
            }
            ViewBag.CountryList = list;
            #endregion

            #region SelectByPK
            if (StateID != null)
            {
                string myConnectingString = Configuration.GetConnectionString("MyConnectingString");
                SqlConnection conn = new SqlConnection(myConnectingString);
                DataTable dt = new DataTable();
                conn.Open();

                SqlCommand sqlCommand = conn.CreateCommand();
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandText = "PR_State_SelectByPK";
                sqlCommand.Parameters.Add("@StateID",SqlDbType.Int).Value = StateID;
                SqlDataReader objred = sqlCommand.ExecuteReader();
                dt.Load(objred);
                 
                    LOC_StateModel modelLOC_State = new LOC_StateModel();

                    foreach (DataRow dr in dt.Rows)
                    {
                        modelLOC_State.StateID = Convert.ToInt32(dr["StateID"]);
                        modelLOC_State.StateName = dr["StateName"].ToString();
                        modelLOC_State.StateCode = dr["StateCode"].ToString();
                        modelLOC_State.CountryID = Convert.ToInt32(dr["CountryID"]);
                        
                    }
                    return View("LOC_StateAddEdit", modelLOC_State);
                
            }
            return View("LOC_StateAddEdit");
            #endregion 
        }

        #region SelectAll
        public IActionResult Index()
        {
            string myConnectingString = Configuration.GetConnectionString("MyConnectingString");
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(myConnectingString);
            conn.Open();
            SqlCommand sqlCommand = conn.CreateCommand();
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.CommandText = "PR_State_SelectAll";
            SqlDataReader objred = sqlCommand.ExecuteReader();
            dt.Load(objred);
            return View("LOC_State_List", dt);
        }
        #endregion

        #region Delete
        public IActionResult Delete(int StateID)
        {
            string myConnectingString = Configuration.GetConnectionString("MyConnectingString");
            SqlConnection conn = new SqlConnection(myConnectingString);
            conn.Open();
            SqlCommand sqlCommand = conn.CreateCommand();
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.CommandText = "PR_State_DeleteByPK";
            sqlCommand.Parameters.AddWithValue("@StateID", StateID);
            sqlCommand.ExecuteNonQuery();
            conn.Close();
            return RedirectToAction("Index");
        }
        #endregion

        #region Insert
        [HttpPost]
        public IActionResult Save(LOC_StateModel modelLOC_State)
        {

            if (!TryValidateModel(modelLOC_State))
            {
                return View("LOC_StateAddEdit");
            }

            string myConnectingString = Configuration.GetConnectionString("MyConnectingString");
            SqlConnection conn = new SqlConnection(myConnectingString);
            conn.Open();
            SqlCommand sqlCommand = conn.CreateCommand();
            sqlCommand.CommandType = CommandType.StoredProcedure;

            if (modelLOC_State.StateID == null)
            {
                sqlCommand.CommandText = "PR_State_Insert";
            }
            else
            {
                sqlCommand.CommandText = "PR_State_UpdateByPK";
                sqlCommand.Parameters.Add("@StateID", SqlDbType.Int).Value = modelLOC_State.StateID;
            }

            sqlCommand.Parameters.Add("@StateName", SqlDbType.VarChar).Value = modelLOC_State.StateName;
            sqlCommand.Parameters.Add("@StateCode", SqlDbType.VarChar).Value = modelLOC_State.StateCode;
            sqlCommand.Parameters.Add("@CountryID", SqlDbType.Int).Value = modelLOC_State.CountryID;
            
                
            if (Convert.ToBoolean(sqlCommand.ExecuteNonQuery()))
            {
                if(modelLOC_State.StateID == null)
                {
                    TempData["LOC_State_Message"] = "Record Inserted Successfully!";
                }
                else
                {
                    TempData["LOC_State_Message"] = "Record Updated Successfully!";
                }
                     
            }
          
            conn.Close();
            return RedirectToAction("Index");
        }
        #endregion

        public IActionResult Cancel()
        {
            return RedirectToAction("Index");
        }

    }
}