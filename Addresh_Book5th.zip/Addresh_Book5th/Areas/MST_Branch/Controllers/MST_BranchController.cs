﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using Addresh_Book5th.Areas.MST_Branch.Models;

namespace Addresh_Book5th.Areas.MST_Branch.Controllers
{
    [Area("MST_Branch")]
    [Route("MST_Branch/{Controller}/{action}")]
    public class MST_BranchController : Controller
    {
        public IConfiguration Configuration;

        public MST_BranchController(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IActionResult Add(int? BranchID)
        {
            if(BranchID != null)
            {
                string connectionString = Configuration.GetConnectionString("MyConnectingString");
                DataTable dt = new DataTable();
                SqlConnection sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();

                SqlCommand objcmd = sqlConnection.CreateCommand();
                objcmd.CommandType = CommandType.StoredProcedure;
                objcmd.CommandText = "PR_MST_Branch_SelectByPK";
                objcmd.Parameters.Add("@BranchID",SqlDbType.Int).Value = BranchID;
                SqlDataReader objred = objcmd.ExecuteReader();
                dt.Load(objred);

                MST_BranchModel modelMST_Branch = new MST_BranchModel();

                foreach(DataRow row in dt.Rows)
                {
                    modelMST_Branch.BranchID = Convert.ToInt32(row["BranchID"]);
                    modelMST_Branch.BranchName = row["BranchName"].ToString();
                    modelMST_Branch.BranchCode = row["BranchCode"].ToString();
                }
                return View("MST_BranchAddEdit", modelMST_Branch);
            }
               return View("MST_BranchAddEdit");
        }

        public IActionResult Index()
        {
            string connectionString = Configuration.GetConnectionString("MyConnectingString");
            DataTable dt = new DataTable();
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            SqlCommand objcmd = sqlConnection.CreateCommand();
            objcmd.CommandType = CommandType.StoredProcedure;
            objcmd.CommandText = "PR_MST_Branch_SelectAll";
            SqlDataReader objred = objcmd.ExecuteReader();
            dt.Load(objred);
            return View("MST_Branch_List", dt);
        }

        public IActionResult Delete(int BranchID)
        {
            string connectionString = Configuration.GetConnectionString("MyConnectingString");
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            SqlCommand objcmd = sqlConnection.CreateCommand();
            objcmd.CommandType = CommandType.StoredProcedure;
            objcmd.CommandText = "PR_MST_Branch_DeleteByPK";
            objcmd.Parameters.AddWithValue("@BranchID", BranchID);
            objcmd.ExecuteNonQuery();
            return RedirectToAction("Index");
        }

        public IActionResult Save(MST_BranchModel modelMST_Branch)
        {
            if (!TryValidateModel(modelMST_Branch))
            {
                return View("MST_BranchAddEdit");
            }

            string connectionString = Configuration.GetConnectionString("MyConnectingString");
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            SqlCommand objcmd = sqlConnection.CreateCommand();
            objcmd.CommandType = CommandType.StoredProcedure;

            if(modelMST_Branch.BranchID == null)
            {
                objcmd.CommandText = "PR_MSR_Branch_Insert";
            }
            else
            {
                objcmd.CommandText = "PR_MST_Branch_UpdateByPK";
                objcmd.Parameters.Add("@BranchID", SqlDbType.Int).Value = modelMST_Branch.BranchID;
            }

            objcmd.Parameters.Add("@BranchName",SqlDbType.VarChar).Value = modelMST_Branch.BranchName;
            objcmd.Parameters.Add("@BranchCode", SqlDbType.VarChar).Value = modelMST_Branch.BranchCode;

            if (Convert.ToBoolean(objcmd.ExecuteNonQuery()))
            {
                if(modelMST_Branch.BranchID == null)
                {
                    TempData["MST_Branch_Insert_Message"] = "Record Inserted Successfully!!";
                }
                else
                {
                    TempData["MST_Branch_Insert_Message"] = "Record Updated Successfully!!";
                }
            }

            return RedirectToAction("Index");  
        }

        public IActionResult Cancel()
        {
            return RedirectToAction("Index");
        }

    }
}
