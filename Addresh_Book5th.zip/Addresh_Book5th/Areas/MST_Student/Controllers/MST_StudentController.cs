﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using Addresh_Book5th.Areas.MST_Student.Models;
using Addresh_Book5th.Areas.LOC_City.Models;
using Addresh_Book5th.Areas.MST_Branch.Models;

namespace Addresh_Book5th.Areas.MST_Student.Controllers
{
    [Area("MST_Student")]
    [Route("MST_Student/{Controller}/{action}")]
    public class MST_StudentController : Controller
    {
        public IConfiguration Configuration;

        public MST_StudentController(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IActionResult Cancle()
        {
            return RedirectToAction("Index");
        }

        public IActionResult Add(int? StudentID)
        {
            #region City Dropdown
            string myconnStr1 = this.Configuration.GetConnectionString("MyConnectingString");
            SqlConnection connection1 = new SqlConnection(myconnStr1);
            DataTable dt1 = new DataTable();
            connection1.Open();
            SqlCommand cmd1 = connection1.CreateCommand();
            cmd1.CommandType = CommandType.StoredProcedure;
            cmd1.CommandText = "PR_LOC_City_Dropdown";
            SqlDataReader reader1 = cmd1.ExecuteReader();
            dt1.Load(reader1);

            List<LOC_City_Dropdown> list = new List<LOC_City_Dropdown>();
            foreach (DataRow dr in dt1.Rows)
            {
                LOC_City_Dropdown lstList = new LOC_City_Dropdown();
                lstList.CityID = Convert.ToInt32(dr["CityID"]);
                lstList.CityName = dr["CityName"].ToString();
                list.Add(lstList);
            }
            ViewBag.CityList = list;
            #endregion

            #region Branch Dropdown
            string myconnStr2 = this.Configuration.GetConnectionString("MyConnectingString");
            SqlConnection connection2 = new SqlConnection(myconnStr2);
            DataTable dt2 = new DataTable();
            connection2.Open();

            SqlCommand cmd2 = connection2.CreateCommand();
            cmd2.CommandType = CommandType.StoredProcedure;
            cmd2.CommandText = "PR_MST_Branch_Dropdown";
            SqlDataReader reader2 = cmd2.ExecuteReader();
            dt2.Load(reader2);

            List<MST_Branch_Dropdown> list1 = new List<MST_Branch_Dropdown>();
            foreach (DataRow dr in dt2.Rows)
            {
                MST_Branch_Dropdown dlist = new MST_Branch_Dropdown();
                dlist.BranchID = Convert.ToInt32(dr["BranchID"]);
                dlist.BranchName = dr["BranchName"].ToString();
                list1.Add(dlist);
            }
            ViewBag.BranchList = list1;
            #endregion

            #region SelectByPK
            if (StudentID != null)
            {
                string myconnStr = this.Configuration.GetConnectionString("MyConnectingString");
                DataTable dt = new DataTable();
                SqlConnection connection = new SqlConnection(myconnStr);
                connection.Open();
                SqlCommand cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "PR_MST_Student_SelectByPK";
                cmd.Parameters.Add("@StudentID",SqlDbType.Int).Value = StudentID;
                SqlDataReader reader = cmd.ExecuteReader();
                dt.Load(reader);
                
                MST_StudentModel modelMST_Student = new MST_StudentModel();
                foreach (DataRow row in dt.Rows)
                {
                    modelMST_Student.StudentID = Convert.ToInt32(row["StudentID"]);
                    modelMST_Student.CityID = Convert.ToInt32(row["CityID"]);
                    modelMST_Student.BranchID = Convert.ToInt32(row["BranchID"]);
                    modelMST_Student.StudentName = row["StudentName"].ToString();
                    modelMST_Student.MobileNoStudent = row["MobileNoStudent"].ToString();
                    modelMST_Student.MobileNoFather = row["MobileNoFather"].ToString();
                    modelMST_Student.Email = row["Email"].ToString();
                    modelMST_Student.Address = row["Address"].ToString();
                    modelMST_Student.BirthDate = Convert.ToDateTime(row["BirthDate"]);
                    modelMST_Student.Age = Convert.ToInt32(row["Age"]);
                    modelMST_Student.IsActive = row["IsActive"].ToString();
                    modelMST_Student.Gender = row["Gender"].ToString();
                    modelMST_Student.Password = row["Password"].ToString();
                }
                return View("MST_StudentAddEdit", modelMST_Student);
            }
            return View("MST_StudentAddEdit");
            #endregion
        }

        #region SelectAll
        public IActionResult Index()
        {
            string myconnStr = this.Configuration.GetConnectionString("MyConnectingString");
            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(myconnStr);
            connection.Open();
            SqlCommand cmd = connection.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "PR_MST_Student_SelectAll";
            SqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            connection.Close();
            return View("MST_Student_List", dt);
        }
        #endregion

        #region Delete
        public IActionResult Delete(int StudentID)
        {
            string myconnStr = this.Configuration.GetConnectionString("MyConnectingString");
            SqlConnection connection = new SqlConnection(myconnStr);
            connection.Open();
            SqlCommand cmd = connection.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "PR_MST_Student_DeleteByPK";
            cmd.Parameters.AddWithValue("@StudentID", StudentID);
            cmd.ExecuteNonQuery();
            connection.Close();
            return RedirectToAction("Index");
        }
        #endregion

        #region Insert
        public IActionResult Save(MST_StudentModel modelMST_Studnet)
        {
            string myconnStr = this.Configuration.GetConnectionString("MyConnectingString");
            SqlConnection connection = new SqlConnection(myconnStr);
            connection.Open();
            SqlCommand cmd = connection.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;

            if(modelMST_Studnet.StudentID == null) 
            {
                cmd.CommandText = "PR_MST_Student_Insert";
            }
            else
            {
                cmd.CommandText = "PR_MST_Student_UpdateByPK";
                cmd.Parameters.Add("@StudentID", SqlDbType.Int).Value = modelMST_Studnet.StudentID;
            }

            cmd.Parameters.Add("@StudentName",SqlDbType.VarChar).Value = modelMST_Studnet.StudentName;
            cmd.Parameters.Add("@BranchID", SqlDbType.Int).Value = modelMST_Studnet.BranchID;
            cmd.Parameters.Add("@CityID", SqlDbType.Int).Value = modelMST_Studnet.CityID;
            cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = modelMST_Studnet.Email;
            cmd.Parameters.Add("@MobileNoStudent", SqlDbType.VarChar).Value = modelMST_Studnet.MobileNoStudent;
            cmd.Parameters.Add("@MobileNoFather", SqlDbType.VarChar).Value = modelMST_Studnet.MobileNoFather;
            cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = modelMST_Studnet.Address;
            cmd.Parameters.Add("@BirthDate", SqlDbType.DateTime).Value = modelMST_Studnet.BirthDate;
            cmd.Parameters.Add("@Age", SqlDbType.Int).Value = modelMST_Studnet.Age;
            cmd.Parameters.Add("@IsActive", SqlDbType.VarChar).Value = modelMST_Studnet.IsActive;
            cmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = modelMST_Studnet.Gender;
            cmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = modelMST_Studnet.Password;

            if (Convert.ToBoolean(cmd.ExecuteNonQuery()))
            {
                if(modelMST_Studnet.StudentID == null)
                {
                    TempData["MST_Student_Insert_Message"] = "Record Inserted Successfully!!";
                }
                else
                {
                    TempData["MST_Student_Insert_Message"] = "Record Updated Successfully!!";
                }
            }
            
            connection.Close();
            return RedirectToAction("Index");
        }
        #endregion
    }
}
