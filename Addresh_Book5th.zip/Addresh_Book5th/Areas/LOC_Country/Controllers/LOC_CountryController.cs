﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using Addresh_Book5th.Areas.LOC_Country.Models;

namespace Addresh_Book5th.Areas.LOC_Country.Controllers
{
    [Area("LOC_Country")]
    [Route("LOC_Country/{Controller}/{action}")]
    public class LOC_CountryController : Controller
    {

        private IConfiguration Configuration;
        public LOC_CountryController(IConfiguration _configuration)
        {
            Configuration = _configuration;
        }

        public IActionResult Add(int? CountryID)
        {
            if(CountryID != null) {
                string connectionString = Configuration.GetConnectionString("MyConnectingString");
                DataTable dt = new DataTable();
                SqlConnection sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();

                SqlCommand objcmd = sqlConnection.CreateCommand();
                objcmd.CommandType = CommandType.StoredProcedure;
                objcmd.CommandText = "PR_Country_SelectByPK";
                objcmd.Parameters.Add("@CountryID", SqlDbType.Int).Value = CountryID;
                SqlDataReader objred = objcmd.ExecuteReader();
                dt.Load(objred);

                LOC_CountryModel model_LOC_Country = new LOC_CountryModel();

                    foreach (DataRow dr in dt.Rows)
                    {
                        model_LOC_Country.CountryID = Convert.ToInt32(dr["CountryID"]);
                        model_LOC_Country.CountryName = dr["CountryName"].ToString();
                        model_LOC_Country.CountryCode = dr["CountryCode"].ToString();
                   
                    }
                    return View("LOC_Country_AddEdit", model_LOC_Country);
                }
            return View("LOC_Country_AddEdit");
        }

        #region SelectAll
        public IActionResult Index()
        {
            string connectionString = Configuration.GetConnectionString("MyConnectingString");
            DataTable dt = new DataTable();
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            SqlCommand objcmd = sqlConnection.CreateCommand();
            objcmd.CommandType = CommandType.StoredProcedure;
            objcmd.CommandText = "PR_Country_SelectAll";
            SqlDataReader objred = objcmd.ExecuteReader();
            dt.Load(objred);
            return View("LOC_Country_List", dt);
        }
        #endregion

        #region Delete
        public IActionResult Delete(int CountryID)
        {
            string connectionString = Configuration.GetConnectionString("MyConnectingString");
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            SqlCommand objcmd = sqlConnection.CreateCommand();
            objcmd.CommandType = CommandType.StoredProcedure;
            objcmd.CommandText = "PR_Country_DeleteByPK";
            objcmd.Parameters.AddWithValue("@CountryID", CountryID);
            objcmd.ExecuteNonQuery();
            sqlConnection.Close();
            return RedirectToAction("Index");
        }
        #endregion

        #region Insert
        [HttpPost]
        public IActionResult Save(LOC_CountryModel modelLOC_Country)
        {
            if (!TryValidateModel(modelLOC_Country))
            {
                return View("LOC_Country_AddEdit");
            }

            string connectionString = Configuration.GetConnectionString("MyConnectingString");
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            SqlCommand objcmd = sqlConnection.CreateCommand();
            objcmd.CommandType = CommandType.StoredProcedure;
           
            if(modelLOC_Country.CountryID == null)
            {
                objcmd.CommandText = "PR_Country_Insert";
            }
            else
            {
                objcmd.CommandText = "PR_Country_UpdateByPK";
                objcmd.Parameters.Add("@CountryID", SqlDbType.Int).Value = modelLOC_Country.CountryID;
            }
            objcmd.Parameters.Add("@CountryName", SqlDbType.VarChar).Value = modelLOC_Country.CountryName;
            objcmd.Parameters.Add("@CountryCode", SqlDbType.VarChar).Value = modelLOC_Country.CountryCode;

            if (Convert.ToBoolean(objcmd.ExecuteNonQuery()))    
            {
                if (modelLOC_Country.CountryID == null)
                {
                    TempData["LOC_Country_Insert_Message"] = "Record Inserted Successfully!!";
                }
                else
                {
                    TempData["LOC_Country_Insert_Message"] = "Record Update Successfully!!";
                }
                    
            }
            sqlConnection.Close();

            return RedirectToAction("Index");
        }
        #endregion

        public IActionResult Cancle()
        {
            return RedirectToAction("Index");
        }

    }
}
